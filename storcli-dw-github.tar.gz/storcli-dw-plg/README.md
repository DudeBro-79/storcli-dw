# storcli-dw — StorCLI HBA Dashboard Plugin for Unraid

A native Unraid dashboard tile plugin for monitoring LSI/Broadcom HBA cards via StorCLI.

Structural approach based on [NUT-unRAID](https://github.com/desertwitch/NUT-unRAID) by desertwitch (Rysz).

## Screenshot

The tile appears natively on your Unraid dashboard alongside CPU, RAM, and array tiles showing:

- **ROC Temperature** — color coded (green < 65°C, orange 65–75°C, red > 75°C) with alert banner if critical
- **Controller Model** — product name reported by storcli
- **Physical Drive Count** — number of drives detected on the HBA
- **Controller State** — health status (defaults to Optimal for IT mode HBAs)

Auto-refreshes every 30 seconds.

## Requirements

- Unraid **6.12.0** or later
- `storcli64` installed at `/usr/local/bin/storcli64`

## Installation

### Via URL (recommended)

In Unraid go to **Plugins → Install Plugin** and paste:

```
https://raw.githubusercontent.com/DudeBro-79/storcli-dw/main/plugin/storcli-dw.plg
```

### Via Community Applications

Search for **storcli-dw** in the Apps tab (once submitted to CA).

## Uninstalling

Go to **Plugins**, find **storcli-dw** and click **Remove**.

## Configuration

Temperature thresholds can be adjusted by editing:
```
/usr/local/emhttp/plugins/storcli-dw/include/storcli_status.php
```

Change `$warn` (default 65°C) and `$crit` (default 75°C) to your preferred values.

Note: edits will be lost on plugin update. A settings page may be added in a future release.

## Compatibility

- Compatible with Unraid 6.12+ (non-responsive dashboard)
- Compatible with Unraid 7.2+ (responsive dashboard)
- Designed for LSI/Broadcom HBAs in **IT mode** (pass-through)
- RAID controllers should also work; controller state reporting may differ

## Tested on

- LSI SAS 9207-8i (IT mode)
- LSI SAS 9215 / N2215 (IT mode)

## Repository structure

```
storcli-dw/
├── plugin/
│   └── storcli-dw.plg                         ← Unraid plugin file
├── packages/
│   └── storcli-plugin-2025.05.25-x86_64-1.txz ← Plugin package
└── source/
    └── usr/local/emhttp/plugins/storcli-dw/
        ├── storcliDashboard.page               ← Dashboard tile
        └── include/
            └── storcli_status.php              ← JSON backend
```

## License

GPL-2.0
