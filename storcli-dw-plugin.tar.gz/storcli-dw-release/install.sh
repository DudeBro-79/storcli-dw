#!/bin/bash
# storcli-dw - StorCLI HBA Dashboard Plugin for Unraid
# Manual installer

set -e

PLUGIN_DIR="/usr/local/emhttp/plugins/storcli-dw"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SOURCE_DIR="$SCRIPT_DIR/source/usr/local/emhttp/plugins/storcli-dw"

echo "================================================"
echo " storcli-dw - StorCLI HBA Dashboard Plugin"
echo "================================================"
echo ""

# Check storcli64 exists
if [ ! -f /usr/local/bin/storcli64 ]; then
    echo "WARNING: storcli64 not found at /usr/local/bin/storcli64"
    echo "         The plugin will install but won't show data until"
    echo "         storcli64 is present at that path."
    echo ""
fi

echo "Installing to $PLUGIN_DIR ..."
mkdir -p "$PLUGIN_DIR/include"
mkdir -p "$PLUGIN_DIR/images"

cp "$SOURCE_DIR/storcliDashboard.page"       "$PLUGIN_DIR/"
cp "$SOURCE_DIR/include/storcli_status.php"  "$PLUGIN_DIR/include/"

chmod 644 "$PLUGIN_DIR/storcliDashboard.page"
chmod 644 "$PLUGIN_DIR/include/storcli_status.php"

echo ""
echo "Installation complete!"
echo ""
echo "Hard-refresh your Unraid dashboard (Ctrl+Shift+R)"
echo "The StorCLI HBA tile will appear showing:"
echo "  - ROC temperature (color coded, alert if critical)"
echo "  - Controller model"
echo "  - Physical drive count"
echo "  - Controller state"
echo ""
echo "Temperature thresholds can be adjusted in:"
echo "  $PLUGIN_DIR/include/storcli_status.php"
echo "  (warn=65°C, crit=75°C)"
echo ""

# Verify
echo "Verifying install..."
php "$PLUGIN_DIR/include/storcli_status.php" 2>/dev/null && echo "" && echo "Backend OK!" || echo "WARNING: PHP test failed - check storcli64 path"
