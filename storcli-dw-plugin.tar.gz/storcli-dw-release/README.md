# storcli-dw — StorCLI HBA Dashboard Plugin for Unraid

A native Unraid dashboard tile plugin for monitoring LSI/Broadcom HBA cards via StorCLI.

## What it shows

- **ROC Temperature** — color coded (green < 65°C, orange 65–75°C, red > 75°C) with alert banner if critical
- **Controller Model** — product name from storcli
- **Physical Drive Count** — number of drives detected
- **Controller State** — health status (defaults to Optimal for IT mode HBAs)

Auto-refreshes every 30 seconds. Compatible with Unraid 6.12+ and the new responsive UI in 7.2+.

## Requirements

- Unraid 6.12 or later
- `storcli64` installed at `/usr/local/bin/storcli64`

## Installation

### Option 1 — Manual (tar.gz)

```bash
# Copy the tar.gz to your Unraid server, then:
cd /tmp
tar -xzf storcli-dw-plugin.tar.gz
cd storcli-dw-release
bash install.sh
```

Then hard-refresh your Unraid dashboard (`Ctrl+Shift+R`).

### Option 2 — Manual file copy

Copy the source files to your Unraid server:

```bash
mkdir -p /usr/local/emhttp/plugins/storcli-dw/include
cp source/usr/local/emhttp/plugins/storcli-dw/storcliDashboard.page /usr/local/emhttp/plugins/storcli-dw/
cp source/usr/local/emhttp/plugins/storcli-dw/include/storcli_status.php /usr/local/emhttp/plugins/storcli-dw/include/
```

## Tested on

- LSI SAS 9207-8i (IT mode)
- LSI SAS 9300-8i (IT mode)
- Broadcom MegaRAID SAS 9361-8i

## Notes

- Designed for HBAs running in **IT mode** (pass-through). RAID controllers should also work but
  controller state reporting may differ.
- Temperature thresholds (warn: 65°C, crit: 75°C) can be adjusted in
  `include/storcli_status.php`.
- Plugin survives Unraid reboots as long as files are placed in `/usr/local/emhttp/plugins/storcli-dw/`.
  To persist across reboots permanently, copy the files to your flash drive and add them to your `go` file,
  or package as a proper `.plg` plugin.

## File structure

```
/usr/local/emhttp/plugins/storcli-dw/
├── storcliDashboard.page       # Dashboard tile injection
└── include/
    └── storcli_status.php      # JSON backend (polled every 30s)
```

## License

GPL-2.0
