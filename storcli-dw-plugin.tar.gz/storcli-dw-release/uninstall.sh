#!/bin/bash
# storcli-dw - StorCLI HBA Dashboard Plugin for Unraid
# Uninstaller

PLUGIN_DIR="/usr/local/emhttp/plugins/storcli-dw"

echo "Removing storcli-dw plugin..."
rm -rf "$PLUGIN_DIR"
echo "Done. Hard-refresh your dashboard (Ctrl+Shift+R)."
